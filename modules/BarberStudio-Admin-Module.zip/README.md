# Admin Module — The Barber Studio
Static admin dashboard. Start with `pages/dashboard.html`.
Includes: dashboard, customers, appointments, payments, services admin,
gallery admin, staff, and settings pages.
