# Login Module — The Barber Studio
Static login page. Open `pages/login.html` in a browser.
Structure:
- pages/login.html
- assets/css, assets/js, assets/images
