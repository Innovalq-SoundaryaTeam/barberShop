# Registration Module — The Barber Studio
Static registration page. Open `pages/register.html` in a browser.
